//
//  MapViewDemoViewController.m
//  BaiduMapTest_RongGe
//
//  Created by 王飞荣 on 16/8/8.
//  Copyright © 2016年 XinYue. All rights reserved.
//

#import "MapViewDemoViewController.h"

@interface MapViewDemoViewController ()<BMKMapViewDelegate>

@end

@implementation MapViewDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if( ([[[UIDevice currentDevice] systemVersion] doubleValue]>=7.0))
    {
        //        self.edgesForExtendedLayout=UIRectEdgeNone;
        self.navigationController.navigationBar.translucent = NO;
    }
    _segment.selectedSegmentIndex = 0;
    [_mapView setTrafficEnabled:NO];
    [_mapView setBuildingsEnabled:YES];
    
    [_mapView setBaiduHeatMapEnabled:NO];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [_mapView viewWillAppear];
    _mapView.delegate = self;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [_mapView viewWillDisappear];
    _mapView.delegate = nil;
}

- (void)dealloc
{
    if(_mapView){
        _mapView = nil;
    }
}

-(IBAction)changeMapType:(id)sender
{
    NSInteger index = _segment.selectedSegmentIndex;
    switch (index) {
        case 0:
            _mapView.mapType = BMKMapTypeStandard;
            break;
        case 1:
            _mapView.mapType = BMKMapTypeSatellite;
            break;
        default:
            break;
    }
}

- (IBAction)switchValueChanged:(id)sender
{
    UISwitch* switchControl = (UISwitch*)sender;
    BOOL isOn = switchControl.isOn;
    switch (switchControl.tag) {
        case 0: //路况
            [_mapView setTrafficEnabled:isOn];
            break;
        case 1: //3D楼宇
            [_mapView setBuildingsEnabled:isOn];
            break;
        case 2: //热力图
            [_mapView setBaiduHeatMapEnabled:isOn];
            break;
        case 3: //底部标注
            [_mapView setShowMapPoi:isOn];
            break;
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
