//
//  addressModel.m
//  BaiduMapTest_RongGe
//
//  Created by 王飞荣 on 16/8/12.
//  Copyright © 2016年 XinYue. All rights reserved.
//

#import "addressModel.h"

@implementation addressModel

@end
