//
//  UIView+Controller.h
//  03 事件分发
//
//  Created by xiaowei on 15/9/11.
//  Copyright (c) 2015年 xiaowei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Controller)

- (UIViewController *)viewController;

@end
