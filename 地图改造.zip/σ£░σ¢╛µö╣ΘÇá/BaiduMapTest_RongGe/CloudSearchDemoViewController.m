//
//  CloudSearchDemoViewController.m
//  BaiduMapTest_RongGe
//
//  Created by 王飞荣 on 16/8/9.
//  Copyright © 2016年 XinYue. All rights reserved.
//

#import "CloudSearchDemoViewController.h"

@implementation CloudSearchDemoViewController

-(void)viewDidLoad
{
    [super viewDidLoad];
    if([[UIDevice currentDevice].systemVersion floatValue]>=7.0){
        self.navigationController.navigationBar.translucent = NO;
    }
    
}

@end
