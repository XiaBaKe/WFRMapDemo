//
//  RootTableViewController.h
//  BaiduMapTest_RongGe
//
//  Created by 王飞荣 on 16/8/8.
//  Copyright © 2016年 XinYue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <BaiduMapAPI_Base/BMKBaseComponent.h>
#import <BaiduMapAPI_Map/BMKMapComponent.h>
#import <BaiduMapAPI_Location/BMKLocationComponent.h>
#import <BaiduMapAPI_Cloud/BMKCloudSearchComponent.h>
#import <BaiduMapAPI_Radar/BMKRadarComponent.h>
#import <BaiduMapAPI_Search/BMKSearchComponent.h>
#import <BaiduMapAPI_Utils/BMKUtilsComponent.h>

@interface RootTableViewController : UITableViewController{
    NSArray*	_demoNameArray;
    NSArray*	_viewControllerArray;
    NSArray*	_viewControllerTitleArray;
}
@end
