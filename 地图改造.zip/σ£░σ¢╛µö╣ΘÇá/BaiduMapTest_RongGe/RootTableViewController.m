//
//  RootTableViewController.m
//  BaiduMapTest_RongGe
//
//  Created by 王飞荣 on 16/8/8.
//  Copyright © 2016年 XinYue. All rights reserved.
//

#import "RootTableViewController.h"
#import "MapViewController.h"
#import "MapViewDemoViewController.h"
#import "LocationDemoViewController.h"
#import "AnnotationDemoViewController.h"
#import "PoiSearchDemoViewController.h"
#import "RouteSearchDemoViewController.h"
#import "CloudSearchDemoViewController.h"
#import "OpenBaiduMapDemo.h"

@interface RootTableViewController ()

@end

@implementation RootTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"欢迎使用百度地图";
//    _viewControllerTitleArray = @[@"钉钉地图",@"图层展示功能",@"定位功能",@"覆盖物和标注功能",@"poi搜索",@"路劲规划功能",@"云检索功能",@"调用百度地图客户端"];
    _viewControllerTitleArray = @[@"钉钉地图"];
    //_viewControllerArray = @[@"钉钉地图"];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Incomplete implementation, return the number of sections
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
#warning Incomplete implementation, return the number of rows
    return _viewControllerTitleArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    // Configure the cell...
    cell.textLabel.text = _viewControllerTitleArray[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView*)tableView didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    switch (indexPath.row) {
        case 0:{
            MapViewController* map = [[MapViewController alloc]init];
            [self.navigationController pushViewController:map animated:YES];
            break;
        }
        case 1:{
            MapViewDemoViewController* demo = [[MapViewDemoViewController alloc]init];
            [self.navigationController pushViewController:demo animated:YES];
            break;
        }
        case 2:{
            LocationDemoViewController* location = [[LocationDemoViewController alloc]init];
            [self.navigationController pushViewController:location animated:YES];
            break;
        }
        case 3:{
            AnnotationDemoViewController* annotation = [[AnnotationDemoViewController alloc]init];
            [self.navigationController pushViewController:annotation animated:YES];
            break;
        }
        case 4:{
            PoiSearchDemoViewController* poiSearch = [[PoiSearchDemoViewController alloc]init];
            [self.navigationController pushViewController:poiSearch animated:YES];
            break;
        }
        case 5:{
            RouteSearchDemoViewController* route = [[RouteSearchDemoViewController alloc]init];
            [self.navigationController pushViewController:route animated:YES];
            break;
        }
        case 6:{
            CloudSearchDemoViewController* Cloud = [[CloudSearchDemoViewController alloc]init];
            [self.navigationController pushViewController:Cloud animated:YES];
            break;
        }
        case 7:{
            OpenBaiduMapDemo* open = [[OpenBaiduMapDemo alloc]init];
            [self.navigationController pushViewController:open animated:YES];
            break;
        }
        default:
            break;
    }
    
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
