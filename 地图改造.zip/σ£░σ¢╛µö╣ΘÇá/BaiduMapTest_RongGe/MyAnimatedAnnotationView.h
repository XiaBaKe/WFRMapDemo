//
//  MyAnimatedAnnotationView.h
//  BaiduMapTest_RongGe
//
//  Created by 王飞荣 on 16/8/9.
//  Copyright © 2016年 XinYue. All rights reserved.
//

#import <BaiduMapAPI_Map/BMKMapComponent.h>

@interface MyAnimatedAnnotationView : BMKAnnotationView

@property(nonatomic, strong) NSMutableArray* annotationImages;
@property(nonatomic, strong) UIImageView* annotationImageView;


@end
