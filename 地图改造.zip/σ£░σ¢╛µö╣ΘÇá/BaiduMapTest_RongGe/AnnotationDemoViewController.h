//
//  AnnotationDemoViewController.h
//  BaiduMapTest_RongGe
//
//  Created by 王飞荣 on 16/8/9.
//  Copyright © 2016年 XinYue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <BaiduMapAPI_Map/BMKMapComponent.h>

@interface AnnotationDemoViewController : UIViewController <BMKMapViewDelegate>{
    __weak IBOutlet BMKMapView *_mapView;
    IBOutlet UISegmentedControl* segment;
}
@end