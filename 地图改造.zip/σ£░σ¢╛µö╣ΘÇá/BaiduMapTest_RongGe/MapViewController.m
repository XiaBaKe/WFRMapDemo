//
//  MapViewController.m
//  BaiduMapTest_RongGe
//
//  Created by 王飞荣 on 16/8/8.
//  Copyright © 2016年 XinYue. All rights reserved.
//

#import "MapViewController.h"
#import <BaiduMapAPI_Location/BMKLocationComponent.h>
#import <BaiduMapAPI_Utils/BMKUtilsComponent.h>
#import <BaiduMapAPI_Search/BMKSearchComponent.h>
#import "CustomTableViewCell.h"
#import "addressModel.h"
#import "SDRefresh.h"
#import "MBProgressHUD+NJ.h"

#define IOS7 [[[UIDevice currentDevice] systemVersion] doubleValue]>=7.0?YES:NO
#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height
#define Kradius 1

@interface MapViewController ()<BMKLocationServiceDelegate,UITableViewDataSource,UITableViewDelegate,BMKPoiSearchDelegate,BMKGeoCodeSearchDelegate,UISearchBarDelegate,UIGestureRecognizerDelegate>

@property(nonatomic) BOOL enableCustomMap;
@property(nonatomic, strong) UISearchBar* searchBar;
@property(nonatomic, strong) BMKLocationService* locationService;
@property(nonatomic, strong) BMKPoiSearch* poiSearch;

@property(nonatomic, strong) BMKNearbySearchOption* nearbySearch;
@property(nonatomic, strong) BMKGeoCodeSearch* geoCode;

@property(nonatomic, strong) UIImageView* locationImage;
@property(nonatomic, strong) UITableView* tabelView;
@property(nonatomic, strong) NSMutableArray* mArray;
@property(nonatomic, strong) SDRefreshFooterView* footerView;
@property(nonatomic, strong) SDRefreshHeaderView* headerView;

@property(nonatomic) int count;
@property(nonatomic) CLLocationCoordinate2D coor;
@property(nonatomic, copy) NSString* address;
@property(nonatomic, strong) CustomTableViewCell* cell;
@property(nonatomic) int index;
@property(nonatomic) BOOL isNeed;

@property(nonatomic, strong) UIButton* searchButton;
@property(nonatomic, strong) UITableView* searchTableView;
@property(nonatomic) int curPage; //poi检索的页码
@property(nonatomic, strong) NSMutableArray* poiArray; //存放poi结果的数组
@property(nonatomic) BOOL ISOne;
@property(nonatomic, strong) UIButton* cancelBtn;
@property(nonatomic, strong) UIView* maskView;
@property(nonatomic) BOOL ISTap;
@property(nonatomic, strong) UIButton* touchdownBtn;
@property(nonatomic, strong) UIView* comfirmView;
@property(nonatomic) CLLocationCoordinate2D userLocation;

@end

@implementation MapViewController

+ (void)initialize
{
    //设置自定义地图样式，会影响所有地图实例
    //必须在BMKMapView对象初始化之前调用
    NSString* path = [[NSBundle mainBundle]pathForResource:@"custom_config_清新蓝" ofType:@""];
    [BMKMapView customMapStyle:path];
}

- (NSMutableArray *)poiArray
{
    if(_poiArray==nil) {
        _poiArray = [NSMutableArray array];
    }
    return _poiArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _mArray = [NSMutableArray array];
    _index = -1;
    self.view.backgroundColor = [UIColor whiteColor];
    //适配IOS7
    if(IOS7){
        self.navigationController.navigationBar.translucent = NO;
    }
    self.title = @"商家位置";
    [self loadSearchBar];
    [self setNavigaBar];
    [self initWithMap];
    [self loadTableView];
    _poiSearch = [[BMKPoiSearch alloc]init];
    _poiSearch.delegate = self;
    _nearbySearch = [[BMKNearbySearchOption alloc]init];
    _geoCode = [[BMKGeoCodeSearch alloc]init];
    _footerView = [SDRefreshFooterView refreshView];
    [_footerView addToScrollView:_searchTableView];
    __weak typeof(self)weakSelf = self;
    weakSelf.footerView.beginRefreshingOperation = ^{
        BMKCitySearchOption* citySearchOption = [[BMKCitySearchOption alloc]init];
        citySearchOption.pageCapacity = 20;
        citySearchOption.pageIndex = weakSelf.curPage;
        citySearchOption.city = @"深圳市";
        citySearchOption.keyword = weakSelf.searchBar.text;
        BOOL flag = [weakSelf.poiSearch poiSearchInCity:citySearchOption];
        if(flag) {
            NSLog(@"成功");
        }

        [weakSelf.footerView endRefreshing];
    };
//    _headerView = [SDRefreshHeaderView refreshView];
//    [_headerView addToScrollView:_tabelView];
//    weakSelf.headerView.beginRefreshingOperation = ^{
//        [self loadAddress:weakSelf];
//    };
}

//- (void)loadAddress:(MapViewController*)weakSelf
//{
//    [weakSelf.mArray removeAllObjects];
//    weakSelf.nearbySearch.location = _coor;
//    weakSelf.nearbySearch.radius = Kradius;
//    weakSelf.nearbySearch.pageCapacity = 30;
//    weakSelf.nearbySearch.pageIndex = 0;
//    weakSelf.nearbySearch.sortType = BMK_POI_SORT_BY_DISTANCE;
//    BOOL flag = [weakSelf.poiSearch poiSearchNearBy:weakSelf.nearbySearch];
//    if(flag) {
//        NSLog(@"成功");
//    }
//    [weakSelf.headerView endRefreshing];
//}

#pragma mark - 设置导航栏颜色和字体
- (void)setNavigaBar
{
    UIBarButtonItem* back = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(backAction)];
    self.navigationItem.leftBarButtonItem = back;
    self.navigationController.navigationBar.tintColor = [UIColor orangeColor];
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:[UIColor orangeColor]};
    UIBarButtonItem* comfirm = [[UIBarButtonItem alloc]initWithTitle:@"确认" style:UIBarButtonItemStylePlain target:self action:@selector(comfirmAction)];
    self.navigationItem.rightBarButtonItem = comfirm;
}

#pragma mark - 初始化地图的方法
- (void)initWithMap
{
    _enableCustomMap = NO;
    _mapView = [[BMKMapView alloc]initWithFrame:CGRectMake(0, 40, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height/2.0-40)];
    _mapView.mapType = BMKMapTypeStandard;
    _mapView.zoomLevel = 14;
    _mapView.overlookEnabled = YES;
    //_mapView.overlooking = ;
    _mapView.logoPosition = BMKLogoPositionRightTop;
    _mapView.showMapScaleBar = YES;
    [_mapView setMapPadding:UIEdgeInsetsMake(0, 0, 0, 0)];
    [self.view addSubview:_mapView];
    
    //用户定位
    _locationService = [[BMKLocationService alloc]init];
    [_locationService startUserLocationService];
    
    UIButton* button = [[UIButton alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_mapView.frame)-40, 80, 40)];
    [button setTitle:@"我的位置" forState:UIControlStateNormal];
    button.backgroundColor = [UIColor purpleColor];
    button.layer.cornerRadius = 5;
    button.layer.masksToBounds = YES;
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(showMeLocation:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
}

#pragma mark - 显示我当前的位置
- (void)showMeLocation:(UIButton*)btn
{
    [_mapView setCenterCoordinate:_userLocation animated:YES];
}

- (void)loadTableView
{
    _tabelView = [[UITableView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_mapView.frame), kScreenWidth, kScreenHeight-CGRectGetMaxY(_mapView.frame)-64)];
    _tabelView.delegate = self;
    _tabelView.dataSource = self;
    [self.view addSubview:_tabelView];
    
    _searchTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 40, kScreenWidth, kScreenHeight-64) style:UITableViewStylePlain];
    //_searchTableView.backgroundColor = [UIColor redColor];
    _searchTableView.delegate = self;
    _searchTableView.dataSource = self;
    _touchdownBtn = [[UIButton alloc]initWithFrame:_searchTableView.bounds];
    _touchdownBtn.backgroundColor = [UIColor clearColor];
    [_touchdownBtn addTarget:self action:@selector(touchTableAction:) forControlEvents:UIControlEventAllTouchEvents];
    [_searchTableView addSubview:_touchdownBtn];
//    UITapGestureRecognizer* tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(touchAction:)];
//    tap.delegate = self;
//    [_searchTableView addGestureRecognizer:tap];
    
    
}

#pragma mark - 隐藏键盘的方法
- (void)touchTableAction:(UIButton*)btn
{
    [_searchBar resignFirstResponder];
    _touchdownBtn.hidden = YES;
}

#pragma mark - 单击手势的回调方法
//- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
//{
//    if([NSStringFromClass([gestureRecognizer.view class])isEqualToString:@"UITableView"]){
//        return YES;
//    }
//    return YES;
//}

#pragma mark - UITableViewDelegate 
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(tableView == _tabelView) {
        return _mArray.count;
    }else{
        return _poiArray.count;
    }
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    _cell = [[CustomTableViewCell alloc]init];
    if(tableView==_tabelView) {
        if(_mArray.count>0) {
            addressModel* model = _mArray[indexPath.row];
            if(indexPath.row==0) {
                _cell.name.text = @"[位置]";
                _cell.name.textColor = [UIColor orangeColor];
                _cell.address.text = model.address;
            }else{
                _cell.name.text = model.name;
                _cell.address.text = model.address;
            }
        }else{
            if(_index==-1) {
                _cell.selectedImage.image = [UIImage imageNamed:@"right_agreen"];
                _index = 0;
            }
        }
        if(indexPath.row == _index) {
            _cell.selectedImage.image = [UIImage imageNamed:@"right_agreen"];
        }
        return _cell;
    }else{
        if(self.poiArray.count>0) {
            addressModel* model = self.poiArray[indexPath.row];
            _cell.name.text = model.name;
            _cell.address.text = model.address;
        }
        return _cell;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

#pragma mark - TableVeiw选中行的方法
- (void)tableView:(UITableView*)tableView didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    if(tableView == _tabelView) {
        if(_index>=0) {
            NSIndexPath* indexPath2 = [NSIndexPath indexPathForRow:_index inSection:0];
            _cell = [tableView cellForRowAtIndexPath:indexPath2];
            _cell.selectedImage.image = [[UIImage alloc]init];
        }
        NSIndexPath* indexPath1 = [_tabelView indexPathForSelectedRow];
        _cell = [tableView cellForRowAtIndexPath:indexPath1];
        _cell.selectedImage.image = [UIImage imageNamed:@"right_agreen"];
        _index = (int)indexPath1.row;
        if(_mArray.count>0){
            addressModel* model = _mArray[_index];
            [_mapView setCenterCoordinate:model.coor animated:YES];
        }
        _isNeed = YES;
    }else{
        _searchTableView.hidden = YES;
        self.navigationController.navigationBar.hidden = NO;
        self.view.transform = CGAffineTransformIdentity;
        CGRect rect = _searchBar.frame;
        rect.size.width += 60;
        _searchBar.frame = rect;
        _cancelBtn.hidden = YES;
        if(_poiArray.count>0){
            addressModel* model = self.poiArray[indexPath.row];
            [_mapView setCenterCoordinate:model.coor animated:YES];
        }
        [_searchBar resignFirstResponder];
        _searchButton.userInteractionEnabled = YES;
        _searchBar.text = @"";
        _ISOne = NO;
    }
}

#pragma mark - 定位的回调方法
- (void)didUpdateBMKUserLocation:(BMKUserLocation *)userLocation
{
    
    //_mapView.centerCoordinate = userLocation.location.coordinate;
    BMKCoordinateSpan span = BMKCoordinateSpanMake(0.004, 0.005);
    _mapView.region = BMKCoordinateRegionMake(userLocation.location.coordinate, span);
    _mapView.showsUserLocation = YES;
    [_mapView updateLocationData:userLocation];
    [_locationService stopUserLocationService];
    _mapView.centerCoordinate = userLocation.location.coordinate;
    _userLocation = userLocation.location.coordinate;
    BMKReverseGeoCodeOption* reverse = [[BMKReverseGeoCodeOption alloc]init];
    reverse.reverseGeoPoint = userLocation.location.coordinate;
    NSLog(@"%f,%f",userLocation.location.coordinate.longitude,userLocation.location.coordinate.latitude);
    BOOL ret = [_geoCode reverseGeoCode:reverse];
    if(ret) {
        NSLog(@"成功");
    }

    CGFloat imageW = 20;
    CGFloat imageH = 30;
    CGFloat ImageX = (_mapView.frame.size.width-imageW)/2.0;
    CGFloat imageY = (_mapView.frame.size.height-imageH)/2.0+40-15;
    _locationImage = [[UIImageView alloc]initWithFrame:CGRectMake(ImageX, imageY, imageW, imageH)];
    _locationImage.image = [UIImage imageNamed:@"serach_Map"];
    _locationImage.contentMode = UIViewContentModeScaleToFill;
    [self.view addSubview:_locationImage];
    [MBProgressHUD hideHUDForView:_tabelView];
}

#pragma mark - 地图区域更改后会调用此接口
- (void)mapView:(BMKMapView *)mapView regionDidChangeAnimated:(BOOL)animated
{
    [MBProgressHUD showMessage:nil toView:_tabelView];
    
    //    _nearbySearch.location = _coor;
//    _nearbySearch.keyword = @"生活";
//    _nearbySearch.radius = Kradius;
//    _nearbySearch.pageCapacity = 30;
//    _nearbySearch.pageIndex = 0;
//    _nearbySearch.sortType = BMK_POI_SORT_BY_DISTANCE;
//    BOOL flag = [_poiSearch poiSearchNearBy:_nearbySearch];
//    if(flag) {
//        NSLog(@"成功");
//    }
    if(!_isNeed){
        [_mArray removeAllObjects];
        NSIndexPath* indexPath2 = [NSIndexPath indexPathForRow:_index inSection:0];
        _cell = [_tabelView cellForRowAtIndexPath:indexPath2];
        _cell.selectedImage.image = [[UIImage alloc]init];

        NSIndexPath* indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
        _cell = [_tabelView cellForRowAtIndexPath:indexPath];
        _cell.selectedImage.image = [UIImage imageNamed:@"right_agreen"];
        _index = 0;
    }
    _coor = [_mapView convertPoint:_locationImage.center toCoordinateFromView:_mapView];
    BMKReverseGeoCodeOption* reverse = [[BMKReverseGeoCodeOption alloc]init];
    reverse.reverseGeoPoint = _coor;
    BOOL ret = [_geoCode reverseGeoCode:reverse];
    if(ret) {
        NSLog(@"成功");
    }


    [MBProgressHUD hideHUDForView:_tabelView];
}

#pragma mark - 反编码的回调方法
- (void)onGetReverseGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKReverseGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error
{
    if(_isNeed) {
        _isNeed = NO;
        return;
    }
    if(error==0) {
        _address = result.address;
        addressModel* model = [[addressModel alloc]init];
        model.address = result.address;
        model.coor = result.location;
        [_mArray addObject:model];
        NSArray* array = result.poiList;
        for(BMKPoiInfo* info in array) {
            addressModel* model = [[addressModel alloc]init];
            model.name = info.name;
            model.address = info.address;
            model.coor = info.pt;
            [_mArray addObject:model];
        }
        [_tabelView reloadData];
    }
    [MBProgressHUD hideHUDForView:_tabelView];
}

//#pragma mark - 周边poi的回调方法
//- (void)onGetPoiResult:(BMKPoiSearch *)searcher result:(BMKPoiResult *)poiResult errorCode:(BMKSearchErrorCode)errorCode
//{
//    if(searcher == _poiSearch) {
//        if(errorCode == BMK_SEARCH_NO_ERROR){
//            if(_isNeed){
//                _isNeed = NO;
//                return;
//            }
//            NSArray* array = poiResult.poiInfoList;
//            NSLog(@"array=%@",array);
//            for(BMKPoiInfo* info in array) {
//                addressModel* model = [[addressModel alloc]init];
//                model.name = info.name;
//                model.address = info.address;
//                model.coor = info.pt;
//                [_mArray addObject:model];
//            }
//            [_tabelView reloadData];
//            _count++;
//        }
//    }
//    [MBProgressHUD hideHUDForView:_tabelView];
//}

- (void)loadSearchBar
{
    _searchBar = [[UISearchBar alloc]initWithFrame:CGRectMake(10,5,kScreenWidth-20, 30)];
    _searchBar.placeholder = @"搜索地址";
    _searchBar.delegate = self;
    //_searchBar.barTintColor = [UIColor lightGrayColor];
    _searchBar.barStyle = UISearchBarStyleMinimal;
    _searchBar.backgroundImage = [[UIImage alloc]init];
    _searchButton = [[UIButton alloc]initWithFrame:_searchBar.bounds];
    _searchButton.backgroundColor = [UIColor clearColor];
    [_searchButton addTarget:self action:@selector(topChangeFrame) forControlEvents:UIControlEventTouchUpInside];
    [_searchBar addSubview:_searchButton];
    [self.view addSubview:_searchBar];
}

#pragma mark - 搜索框上移的方法
- (void)topChangeFrame
{
    [_searchBar becomeFirstResponder];
    _searchButton.userInteractionEnabled = NO;
    self.navigationController.navigationBar.hidden = YES;
    self.view.transform = CGAffineTransformMakeTranslation(0, -40);
    CGRect rect = _searchBar.frame;
    rect.size.width -= 60;
    _searchBar.frame = rect;
    
    if(_cancelBtn==nil) {
        _cancelBtn = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_searchBar.frame)+5, _searchBar.frame.origin.y, kScreenWidth-_searchBar.frame.size.width-20, 30)];
        [_cancelBtn setTitle:@"取消" forState:UIControlStateNormal];
        [_cancelBtn setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
        _cancelBtn.tag = 100;
        [_cancelBtn addTarget:self action:@selector(cancelAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:_cancelBtn];
    }else{
        _cancelBtn.hidden = NO;
    }
    if(_maskView==nil) {
        _maskView = [[UIView alloc]initWithFrame:CGRectMake(0, 40, kScreenWidth, kScreenHeight-40)];
        _maskView.tag = 101;
        _maskView.backgroundColor = [UIColor colorWithWhite:.3 alpha:.6];
        [self.view addSubview:_maskView];
    }else{
        _maskView.hidden = NO;
    }
}

#pragma mark - UISearchBarDelegate 的方法
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if(searchBar.text.length==0) {
        return;
    }
    [MBProgressHUD showMessage:@"正在加载中..."];
    [_poiArray removeAllObjects];
    if(!_ISOne){
        _searchTableView.hidden = NO;
        [self.view addSubview:_searchTableView];
        _maskView.hidden = YES;
    }
    _curPage = 0;
    BMKCitySearchOption* citySearchOption = [[BMKCitySearchOption alloc]init];
    citySearchOption.pageCapacity = 20;
    citySearchOption.pageIndex = _curPage;
    citySearchOption.city = @"深圳市";
    citySearchOption.keyword = _searchBar.text;
    BOOL flag = [_poiSearch poiSearchInCity:citySearchOption];
    if(flag) {
        NSLog(@"成功");
    }
    _ISOne = YES;
    [MBProgressHUD hideHUD];
}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar{
    _touchdownBtn.hidden = NO;
    return YES;
}

-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [searchBar resignFirstResponder];
}

#pragma mark - poi搜索结果
- (void)onGetPoiResult:(BMKPoiSearch *)searcher result:(BMKPoiResult *)poiResult errorCode:(BMKSearchErrorCode)errorCode
{
    [MBProgressHUD hideHUD];
    if(errorCode == 0) {
        NSArray* array = poiResult.poiInfoList;
        for(BMKPoiInfo* info in array) {
            addressModel* model = [[addressModel alloc]init];
            model.name = info.name;
            model.address = info.address;
            model.coor = info.pt;
            [self.poiArray addObject:model];
        }
        _curPage++;
    }else{
        [MBProgressHUD showError:@"找不到您搜的地址"];
    }
    [_searchTableView reloadData];
}

#pragma mark - 取消的方法
- (void)cancelAction:(UIButton*)btn
{
    _searchTableView.hidden = YES;
    self.navigationController.navigationBar.hidden = NO;
    _maskView.hidden = YES;
    self.view.transform = CGAffineTransformIdentity;
    CGRect rect = _searchBar.frame;
    rect.size.width += 60;
    _searchBar.frame = rect;
    _cancelBtn.hidden = YES;
    [_searchBar resignFirstResponder];
    _searchButton.userInteractionEnabled = YES;
    _searchBar.text = @"";
    _ISOne = NO;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    
}

#pragma mark - 返回上一个界面的方法
- (void)backAction
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - 确定的方法
- (void)comfirmAction
{
    if(_comfirmView==nil){
        _comfirmView = [[UIView alloc]initWithFrame:CGRectMake((kScreenWidth-300)/2.0, (kScreenHeight-100-64-50)/2, 300, 100)];
        _comfirmView.backgroundColor = [UIColor whiteColor];
        UITextField* textField = [[UITextField alloc]initWithFrame:CGRectMake(0, 10, 300, 30)];
        textField.borderStyle = UITextBorderStyleRoundedRect;
        if(_mArray.count>0){
            addressModel* model = _mArray[0];
            textField.text = model.address;
        }
        [_comfirmView addSubview:textField];
        UIButton* button = [[UIButton alloc]initWithFrame:CGRectMake(75, 50, 150, 40)];
        [button addTarget:self action:@selector(comfirmButton:) forControlEvents:UIControlEventTouchUpInside];
        [button setTitle:@"确定" forState:UIControlStateNormal];
        button.backgroundColor = [UIColor orangeColor];
        [_comfirmView addSubview:button];
        button.layer.masksToBounds = YES;
        button.layer.cornerRadius = 5;
        [self.view addSubview:_comfirmView];
    }else{
        _comfirmView.hidden = NO;
    }
}

- (void)comfirmButton:(UIButton*)btn
{
    _comfirmView.hidden = YES;
    [self.view endEditing:YES];
}

- (void)changeMapTypeAction:(UISegmentedControl*)segment
{
    _enableCustomMap = segment.selectedSegmentIndex==1;
    [BMKMapView enableCustomMapStyle:_enableCustomMap];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [_mapView viewWillAppear];
    _mapView.delegate = self;
    _locationService.delegate = self;
    _poiSearch.delegate = self;
    _geoCode.delegate = self;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [_mapView viewWillDisappear];
    _mapView.delegate = nil;
    _locationService.delegate = nil;
    _poiSearch.delegate = nil;
    _geoCode.delegate = nil;
}

- (void)dealloc
{
    if(_mapView){
        _mapView = nil;
    }
    if(_locationService) {
        _locationService = nil;
    }
    if(_poiSearch){
        _poiSearch = nil;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
