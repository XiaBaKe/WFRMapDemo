//
//  CustomTableViewCell.h
//  BaiduMapTest_RongGe
//
//  Created by 王飞荣 on 16/8/11.
//  Copyright © 2016年 XinYue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *address;
@property (weak, nonatomic) IBOutlet UIImageView *selectedImage;

@end
