//
//  MapViewController.h
//  BaiduMapTest_RongGe
//
//  Created by 王飞荣 on 16/8/8.
//  Copyright © 2016年 XinYue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <BaiduMapAPI_Map/BMKMapComponent.h>

@interface MapViewController : UIViewController<BMKMapViewDelegate>
@property(nonatomic, strong) BMKMapView* mapView;

@end
