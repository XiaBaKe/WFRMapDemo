//
//  AnnotationDemoViewController.m
//  BaiduMapTest_RongGe
//
//  Created by 王飞荣 on 16/8/9.
//  Copyright © 2016年 XinYue. All rights reserved.
//

#import "AnnotationDemoViewController.h"
#import "MyAnimatedAnnotationView.h"

@interface AnnotationDemoViewController ()
{
    BMKPointAnnotation* pointAnnotation;
    BMKPointAnnotation* animatedAnnotation;
}

@end

@implementation AnnotationDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if([[UIDevice currentDevice].systemVersion floatValue]>=7.0){
        self.navigationController.navigationBar.translucent = NO;
    }
    [_mapView setZoomLevel:11];
    segment.selectedSegmentIndex = 0;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [_mapView viewWillAppear];
    _mapView.delegate = self;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [_mapView viewWillDisappear];
    _mapView.delegate = nil;
}

- (void)dealloc
{
    if(_mapView){
        _mapView = nil;
    }
}

- (IBAction)segmentChanged:(id)sender {
    UISegmentedControl* segment = (UISegmentedControl*)sender;
    if(segment.selectedSegmentIndex ==1){
        [self addPointAnnotation];
        [self addAnimatedAnnotation];
        return;
    }
}

- (void)addPointAnnotation
{
    if(pointAnnotation ==nil){
        pointAnnotation = [[BMKPointAnnotation alloc]init];
        CLLocationCoordinate2D coor;
        coor.latitude = 40.115;
        coor.longitude = 116.404;
        pointAnnotation.coordinate = coor;
        pointAnnotation.title = @"测试";
        pointAnnotation.subtitle = @"我是帅哥";
    }
    [_mapView addAnnotation:pointAnnotation];
}

- (void)addAnimatedAnnotation
{
    if(animatedAnnotation==nil){
        animatedAnnotation = [[BMKPointAnnotation alloc]init];
        CLLocationCoordinate2D coor;
        coor.latitude = 39.915;
        coor.longitude = 116.404;
        animatedAnnotation.coordinate = coor;
        animatedAnnotation.title = @"我是动画title";
    }
    [_mapView addAnnotation:animatedAnnotation];
}

//根据anntation生成对应的View
- (BMKAnnotationView *)mapView:(BMKMapView *)mapView viewForAnnotation:(id<BMKAnnotation>)annotation
{
    if(annotation == pointAnnotation) {
        NSString* AnnotationViewID = @"renameMark";
        BMKPinAnnotationView* annotationView = (BMKPinAnnotationView*)[mapView dequeueReusableAnnotationViewWithIdentifier:AnnotationViewID];
        if(annotationView==nil) {
            annotationView = [[BMKPinAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:AnnotationViewID];
            annotationView.pinColor = BMKPinAnnotationColorGreen;
            annotationView.animatesDrop = YES;
            annotationView.draggable = YES;
        }
        return annotationView;
    }
    NSString* AnnotationViewID = @"AnimatedAnnotation";
    MyAnimatedAnnotationView* annotationView = nil;
    if(annotationView==nil) {
        annotationView = [[MyAnimatedAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:AnnotationViewID];
    }
    NSMutableArray* images = [NSMutableArray array];
    for(int i=1; i<4; i++) {
        UIImage* image= [UIImage imageNamed:[NSString stringWithFormat:@"poi_%d.png",i]];
        [images addObject:image];
    }
    annotationView.annotationImages = images;
    return annotationView;
}

- (void)mapView:(BMKMapView *)mapView annotationViewForBubble:(BMKAnnotationView *)view;
{
    NSLog(@"paopaoclick");
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
