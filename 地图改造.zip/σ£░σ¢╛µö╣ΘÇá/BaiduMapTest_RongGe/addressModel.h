//
//  addressModel.h
//  BaiduMapTest_RongGe
//
//  Created by 王飞荣 on 16/8/12.
//  Copyright © 2016年 XinYue. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <BaiduMapAPI_Location/BMKLocationComponent.h>

@interface addressModel : NSObject

@property(nonatomic, copy) NSString* name;
@property(nonatomic, copy) NSString* address;
@property(nonatomic) CLLocationCoordinate2D coor;
@end
