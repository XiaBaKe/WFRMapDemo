//
//  CustomTableViewCell.m
//  BaiduMapTest_RongGe
//
//  Created by 王飞荣 on 16/8/11.
//  Copyright © 2016年 XinYue. All rights reserved.
//

#import "CustomTableViewCell.h"

@implementation CustomTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self) {
        UIView* view = [[[NSBundle mainBundle]loadNibNamed:@"CustomTableViewCell" owner:nil options:nil]lastObject];
        self = (CustomTableViewCell*)view;
    }
    return self;
}

- (void)awakeFromNib{
//    UIView* view = [[[NSBundle mainBundle]loadNibNamed:@"CustomTableViewCell" owner:self options:nil]lastObject];
//    view.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 60);
//    view.userInteractionEnabled = YES;
//    [self.contentView addSubview:view];
}
@end
